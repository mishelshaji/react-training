import {getAllCategories} from "../services/categoryService";

export const getAll = (_: Request, res: Response) => {
    const result = getAllCategories();
    res.status(200).json(result);
}
