import express from 'express';
import db from "./database";

const app = express();
const PORT = 8000;

app.get('/api/category', (_, res) => {
    const sql = 'SELECT id, name, description FROM categories';
    db.all(sql, (errors, rows)=>{
        return res.status(200).json(rows);
    })
})

app.get('/api/category/:id', (req, res) => {
    const id = req.params.id;
    const sql = 'SELECT id, name, description FROM categories WHERE id = ?';
    db.get(sql, [id], (errors, row)=>{
        return res.status(200).json(row);
    })
})

app.get('/api/product', (_, res) => {
    const sql = 'SELECT * FROM products';
    db.all(sql, (errors, rows)=>{
        return res.status(200).json(rows);
    })
})

app.get('/api/product/:id', (req, res) => {
    const id = req.params.id;
    const sql = 'SELECT * FROM products WHERE id = ?';
    db.get(sql, [id], (errors, row)=>{
        return res.status(200).json(row);
    })
})

app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
