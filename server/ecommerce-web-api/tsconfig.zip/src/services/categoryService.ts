import db from "../database";

export const getAllCategories = () => {
    const sql = 'SELECT id, name, description FROM categories';
    db.all(sql, (errors, rows)=>{
        return rows;
    })
}
