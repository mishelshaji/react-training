import {Router} from "express";
import {getAll} from "../controllers/categoryController";

const router = Router();

router.get('/api/category', getAll);
